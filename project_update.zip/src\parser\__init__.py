"""Parser module for Polymarket API interactions."""

