"""Database module for trade data storage."""

